#include "print.h"

int main() {
	print();
	return 0;
}

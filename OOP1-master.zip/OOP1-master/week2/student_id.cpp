#include "student_id.h"

int student_id() {
	return 201202164;
}

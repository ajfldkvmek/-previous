#include "print.h"
#include "student_id.h"

void print() {
	std::cout << student_id() << "Kim HyeonTae" << std::endl;
}

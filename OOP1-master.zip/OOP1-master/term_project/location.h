#pragma once
class location {
public:
	int x;
	int y;
	int color;

	location(int x, int y, int color) {
		this->x = x;
		this->y = y;
		this->color = color;
	}
};
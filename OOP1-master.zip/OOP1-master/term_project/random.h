#pragma once

class Random {

public: 
	enum Color {
		gray,
		red,
		green,
		blue
	};
	enum Shape {
		fold,
		tree,
		cross
	};
};
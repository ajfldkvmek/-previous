#include <iostream>

int main() {
	//char * a = "ABC";	
	char b[] = "ABC";
	//a[0] = 'b';
	b[1] = 'Z';
	std::cout << b << std::endl;
}


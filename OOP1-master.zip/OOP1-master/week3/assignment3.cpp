#include <iostream>

int main() {

	char target[] = "Kim HyeonTae";
	long b[164];
	int a = 17;
	int i = 1348;//find
	int *c = new int[202];
	char * copy = "is no no";
	char name = 'a';
	
	std::cout << &name+i << std::endl;

	return 0;
}

#include <iostream>

int main() {
	int a = 10;
	char b = 'a';
	char *as = "QWE";
	std::cout << &a << std::endl;
	std::cout << &b << std::endl;
	std::cout << b << std::endl;
	
}
